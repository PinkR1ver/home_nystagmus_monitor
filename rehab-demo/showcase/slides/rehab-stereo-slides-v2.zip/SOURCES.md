# Showcase media sources

Accessed and prepared on 2026-08-28. The clips are used as visual demonstration inputs;
all model outputs and measurements shown beside them remain explicitly marked as demo data.

## Full-body pose clip

- Title: “Woman doing squats”
- Canonical page: https://mixkit.co/free-stock-video/woman-doing-squats-752/
- License: Mixkit Stock Video Free License
- Retrieval mirror: https://huggingface.co/datasets/FastVideo/Mixkit-Src
- Local source: `source-media/mixkit-squats-752.mp4`
- Changes: selected a wide, unobstructed full-body take; slowed to 50%; resized and padded
  to 1280×720; converted to H.264 at 30 fps; removed audio.

## Nystagmus clip

- Title: “Video-4.mp4”
- Author: Ajay Kumar Vats
- Canonical page and DOI: https://doi.org/10.6084/m9.figshare.28794470
- License: Creative Commons Attribution 4.0 International (CC BY 4.0)
- Local source: `source-media/figshare-nystagmus-video4.mp4`
- Changes: extracted 126–136 seconds from the real VNG recording; cropped to the paired
  eye displays; resized to 1280×720; converted to H.264 at 30 fps; removed audio.

The nystagmus source describes geotropic/apogeotropic horizontal positional nystagmus with
subtle vertical components. Its inclusion does not imply endorsement of this project by the
author or Figshare.
